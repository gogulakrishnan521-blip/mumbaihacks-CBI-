import { z } from "zod";

export const transactionCategories = [
  "food",
  "transportation",
  "utilities",
  "entertainment",
  "shopping",
  "healthcare",
  "housing",
  "income",
  "investment",
  "other"
] as const;

export type TransactionCategory = typeof transactionCategories[number];

export interface Transaction {
  id: string;
  date: string;
  description: string;
  category: TransactionCategory;
  amount: number;
  type: "income" | "expense";
}

export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  type: "long-term" | "short-term";
  icon: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface BudgetCategory {
  name: string;
  amount: number;
  color: string;
}

export interface StockData {
  date: string;
  value: number;
}

export interface DashboardData {
  dailyGoal: string;
  totalBalance: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  savingsRate: number;
  budgetPie: BudgetCategory[];
  stockData: StockData[];
}

export interface BankConnection {
  id: string;
  bankName: string;
  accountNumber: string;
  routingNumber: string;
  status: "connected" | "pending" | "failed";
}

export const insertTransactionSchema = z.object({
  date: z.string(),
  description: z.string().min(1),
  category: z.enum(transactionCategories),
  amount: z.number().min(0.01),
  type: z.enum(["income", "expense"])
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export const insertGoalSchema = z.object({
  name: z.string().min(1),
  targetAmount: z.number().positive(),
  currentAmount: z.number().min(0),
  deadline: z.string(),
  type: z.enum(["long-term", "short-term"]),
  icon: z.string()
});

export type InsertGoal = z.infer<typeof insertGoalSchema>;

export const insertChatMessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().min(1)
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export const insertBankConnectionSchema = z.object({
  bankName: z.string().min(1),
  accountNumber: z.string().min(1),
  routingNumber: z.string().min(1)
});

export type InsertBankConnection = z.infer<typeof insertBankConnectionSchema>;

export const csvUploadSchema = z.object({
  transactions: z.array(insertTransactionSchema)
});

export type User = {
  id: string;
  username: string;
  password: string;
};

export type InsertUser = {
  username: string;
  password: string;
};
