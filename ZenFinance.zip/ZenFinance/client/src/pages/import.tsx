import { useState, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Upload,
  FileSpreadsheet,
  Check,
  X,
  AlertCircle,
  ArrowRight,
} from "lucide-react";
import type { InsertTransaction, TransactionCategory } from "@shared/schema";
import { transactionCategories } from "@shared/schema";

interface ParsedTransaction {
  date: string;
  description: string;
  amount: number;
  type: "income" | "expense";
  category: TransactionCategory;
}

function parseCSV(text: string): ParsedTransaction[] {
  const lines = text.trim().split("\n");
  if (lines.length < 2) return [];

  const headers = lines[0].toLowerCase().split(",").map((h) => h.trim());
  const dateIdx = headers.findIndex((h) => h.includes("date"));
  const descIdx = headers.findIndex((h) => h.includes("desc") || h.includes("name") || h.includes("memo"));
  const amountIdx = headers.findIndex((h) => h.includes("amount") || h.includes("value"));
  const categoryIdx = headers.findIndex((h) => h.includes("category") || h.includes("type"));

  if (dateIdx === -1 || amountIdx === -1) {
    throw new Error("CSV must contain 'date' and 'amount' columns");
  }

  return lines.slice(1).map((line, index) => {
    const values = line.split(",").map((v) => v.trim().replace(/"/g, ""));
    const amount = parseFloat(values[amountIdx]);
    const isExpense = amount < 0;

    let category: TransactionCategory = "other";
    if (categoryIdx !== -1) {
      const rawCategory = values[categoryIdx]?.toLowerCase();
      if (transactionCategories.includes(rawCategory as TransactionCategory)) {
        category = rawCategory as TransactionCategory;
      }
    }

    return {
      date: values[dateIdx] || new Date().toISOString().split("T")[0],
      description: values[descIdx] || `Transaction ${index + 1}`,
      amount: Math.abs(amount),
      type: isExpense ? "expense" : "income",
      category,
    };
  }).filter((t) => !isNaN(t.amount) && t.amount > 0);
}

function DropZone({
  onFileDrop,
  isProcessing,
}: {
  onFileDrop: (file: File) => void;
  isProcessing: boolean;
}) {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files[0];
      if (file && file.name.endsWith(".csv")) {
        onFileDrop(file);
      }
    },
    [onFileDrop]
  );

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
        onFileDrop(file);
      }
    },
    [onFileDrop]
  );

  return (
    <div
      className={`relative border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
        isDragging
          ? "border-primary bg-primary/5"
          : "border-border hover:border-primary/50"
      } ${isProcessing ? "opacity-50 pointer-events-none" : ""}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      data-testid="dropzone-csv"
    >
      <input
        type="file"
        accept=".csv"
        onChange={handleFileInput}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        disabled={isProcessing}
        data-testid="input-file-csv"
      />
      <div className="flex flex-col items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-muted">
          <FileSpreadsheet className="h-8 w-8 text-muted-foreground" />
        </div>
        <div>
          <p className="text-lg font-medium">
            {isDragging ? "Drop your CSV file here" : "Drop CSV file here or click to browse"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            Supports CSV files with date, description, and amount columns
          </p>
        </div>
      </div>
    </div>
  );
}

function PreviewTable({
  transactions,
  onCategoryChange,
}: {
  transactions: ParsedTransaction[];
  onCategoryChange: (index: number, category: TransactionCategory) => void;
}) {
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Preview ({transactions.length} transactions)</CardTitle>
        <CardDescription>
          Review and categorize your transactions before importing
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="text-right">Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.slice(0, 10).map((t, index) => (
              <TableRow key={index} data-testid={`row-preview-${index}`}>
                <TableCell className="font-medium">{t.date}</TableCell>
                <TableCell className="max-w-[200px] truncate">{t.description}</TableCell>
                <TableCell>
                  <Select
                    value={t.category}
                    onValueChange={(value) =>
                      onCategoryChange(index, value as TransactionCategory)
                    }
                  >
                    <SelectTrigger className="w-32" data-testid={`select-category-${index}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {transactionCategories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat.charAt(0).toUpperCase() + cat.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  <Badge variant={t.type === "income" ? "default" : "secondary"}>
                    {t.type}
                  </Badge>
                </TableCell>
                <TableCell
                  className={`text-right font-medium tabular-nums ${
                    t.type === "income" ? "text-emerald-600" : "text-red-600"
                  }`}
                >
                  {t.type === "income" ? "+" : "-"}
                  {formatCurrency(t.amount)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {transactions.length > 10 && (
          <div className="p-4 text-center text-sm text-muted-foreground border-t">
            ...and {transactions.length - 10} more transactions
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Import() {
  const [parsedData, setParsedData] = useState<ParsedTransaction[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (transactions: InsertTransaction[]) => {
      return apiRequest("POST", "/api/transactions/bulk", { transactions });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setParsedData(null);
      toast({
        title: "Import successful",
        description: `${parsedData?.length} transactions have been imported.`,
      });
    },
    onError: () => {
      toast({
        title: "Import failed",
        description: "Failed to import transactions. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileDrop = async (file: File) => {
    setError(null);
    try {
      const text = await file.text();
      const parsed = parseCSV(text);
      if (parsed.length === 0) {
        throw new Error("No valid transactions found in the CSV file");
      }
      setParsedData(parsed);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to parse CSV file");
      setParsedData(null);
    }
  };

  const handleCategoryChange = (index: number, category: TransactionCategory) => {
    if (!parsedData) return;
    const updated = [...parsedData];
    updated[index] = { ...updated[index], category };
    setParsedData(updated);
  };

  const handleImport = () => {
    if (!parsedData) return;
    const transactions: InsertTransaction[] = parsedData.map((t) => ({
      date: t.date,
      description: t.description,
      amount: t.amount,
      type: t.type,
      category: t.category,
    }));
    uploadMutation.mutate(transactions);
  };

  const handleCancel = () => {
    setParsedData(null);
    setError(null);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Import Transactions</h1>
        <p className="text-muted-foreground mt-1">
          Upload a CSV file to import your transaction history
        </p>
      </div>

      {error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-destructive" />
              <p className="text-destructive">{error}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {!parsedData ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload CSV File
            </CardTitle>
            <CardDescription>
              Your CSV file should include columns for date, description, and amount.
              Category column is optional.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DropZone onFileDrop={handleFileDrop} isProcessing={false} />

            <div className="mt-6">
              <h3 className="font-medium mb-3">CSV Format Example</h3>
              <div className="bg-muted rounded-lg p-4 font-mono text-sm overflow-x-auto">
                <pre>
{`date,description,amount,category
2024-01-15,Grocery Store,-125.50,food
2024-01-14,Salary,3500.00,income
2024-01-13,Gas Station,-45.00,transportation`}
                </pre>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          <PreviewTable
            transactions={parsedData}
            onCategoryChange={handleCategoryChange}
          />

          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={handleCancel} data-testid="button-cancel-import">
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleImport}
              disabled={uploadMutation.isPending}
              data-testid="button-confirm-import"
            >
              {uploadMutation.isPending ? (
                "Importing..."
              ) : (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Import {parsedData.length} Transactions
                </>
              )}
            </Button>
          </div>
        </div>
      )}

      <Card className="bg-muted/50">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
              <ArrowRight className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium mb-1">Need to connect a bank?</h3>
              <p className="text-sm text-muted-foreground">
                For automatic transaction syncing, you can connect your bank account
                directly in the Bank Connection section.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
