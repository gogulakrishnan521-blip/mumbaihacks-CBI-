import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Building2,
  Plus,
  Shield,
  CheckCircle2,
  XCircle,
  Clock,
  Trash2,
  Lock,
} from "lucide-react";
import type { BankConnection, InsertBankConnection } from "@shared/schema";

const banks = [
  { value: "chase", label: "Chase Bank" },
  { value: "bofa", label: "Bank of America" },
  { value: "wells", label: "Wells Fargo" },
  { value: "citi", label: "Citibank" },
  { value: "usbank", label: "US Bank" },
  { value: "pnc", label: "PNC Bank" },
  { value: "capital", label: "Capital One" },
  { value: "other", label: "Other" },
];

const connectionSchema = z.object({
  bankName: z.string().min(1, "Please select a bank"),
  accountNumber: z.string().min(4, "Account number is required").max(20),
  routingNumber: z.string().length(9, "Routing number must be 9 digits"),
});

function getStatusBadge(status: BankConnection["status"]) {
  switch (status) {
    case "connected":
      return (
        <Badge variant="default" className="gap-1 bg-emerald-500 hover:bg-emerald-600">
          <CheckCircle2 className="h-3 w-3" />
          Connected
        </Badge>
      );
    case "pending":
      return (
        <Badge variant="secondary" className="gap-1">
          <Clock className="h-3 w-3" />
          Pending
        </Badge>
      );
    case "failed":
      return (
        <Badge variant="destructive" className="gap-1">
          <XCircle className="h-3 w-3" />
          Failed
        </Badge>
      );
  }
}

function maskAccountNumber(accountNumber: string): string {
  if (accountNumber.length <= 4) return accountNumber;
  return "****" + accountNumber.slice(-4);
}

function BankConnectionCard({
  connection,
  onDelete,
}: {
  connection: BankConnection;
  onDelete: (id: string) => void;
}) {
  const bankLabel = banks.find((b) => b.value === connection.bankName)?.label || connection.bankName;

  return (
    <Card className="hover-elevate" data-testid={`card-bank-${connection.id}`}>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <Building2 className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold">{bankLabel}</h3>
              <p className="text-sm text-muted-foreground">
                Account: {maskAccountNumber(connection.accountNumber)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Routing: {connection.routingNumber}
              </p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            {getStatusBadge(connection.status)}
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
              onClick={() => onDelete(connection.id)}
              data-testid={`button-delete-bank-${connection.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function AddBankDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof connectionSchema>>({
    resolver: zodResolver(connectionSchema),
    defaultValues: {
      bankName: "",
      accountNumber: "",
      routingNumber: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (values: InsertBankConnection) => {
      return apiRequest("POST", "/api/bank-connections", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-connections"] });
      setOpen(false);
      form.reset();
      toast({
        title: "Bank connection initiated",
        description: "Your bank connection is being processed. This may take a few moments.",
      });
    },
    onError: () => {
      toast({
        title: "Connection failed",
        description: "Failed to connect bank. Please check your details and try again.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(values: z.infer<typeof connectionSchema>) {
    mutation.mutate(values);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-add-bank">
          <Plus className="h-4 w-4 mr-2" />
          Connect Bank
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Connect Your Bank</DialogTitle>
          <DialogDescription>
            Enter your bank details to sync your transactions automatically.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="bankName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bank</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-bank">
                        <SelectValue placeholder="Select your bank" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {banks.map((bank) => (
                        <SelectItem key={bank.value} value={bank.value}>
                          {bank.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="accountNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Account Number</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter account number"
                      type="password"
                      autoComplete="off"
                      {...field}
                      data-testid="input-account-number"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="routingNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Routing Number</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="9-digit routing number"
                      maxLength={9}
                      {...field}
                      data-testid="input-routing-number"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex items-center gap-2 p-3 rounded-lg bg-muted text-sm">
              <Lock className="h-4 w-4 text-muted-foreground shrink-0" />
              <p className="text-muted-foreground">
                Your data is encrypted and secure. We never store your login credentials.
              </p>
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={mutation.isPending}
              data-testid="button-submit-bank"
            >
              {mutation.isPending ? "Connecting..." : "Connect Bank"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function BankConnectionsSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {[1, 2].map((i) => (
        <Skeleton key={i} className="h-32" />
      ))}
    </div>
  );
}

export default function Bank() {
  const { toast } = useToast();

  const { data: connections, isLoading, error } = useQuery<BankConnection[]>({
    queryKey: ["/api/bank-connections"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/bank-connections/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-connections"] });
      toast({
        title: "Bank disconnected",
        description: "Your bank connection has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to disconnect bank. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold">Bank Connections</h1>
            <p className="text-muted-foreground mt-1">
              Connect your bank accounts for automatic transaction syncing
            </p>
          </div>
          <Skeleton className="h-10 w-36" />
        </div>
        <BankConnectionsSkeleton />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="pt-6">
            <p className="text-destructive">
              Failed to load bank connections. Please try again.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Bank Connections</h1>
          <p className="text-muted-foreground mt-1">
            Connect your bank accounts for automatic transaction syncing
          </p>
        </div>
        <AddBankDialog />
      </div>

      <Card className="bg-gradient-to-br from-primary/5 via-transparent to-transparent border-primary/20">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">Bank-Level Security</h3>
              <p className="text-sm text-muted-foreground">
                Your financial data is protected with 256-bit encryption. We use
                read-only access to view your transactions and never have permission
                to move money or make changes to your accounts.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {connections && connections.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2">
          {connections.map((connection) => (
            <BankConnectionCard
              key={connection.id}
              connection={connection}
              onDelete={(id) => deleteMutation.mutate(id)}
            />
          ))}
        </div>
      ) : (
        <Card className="border-dashed">
          <CardContent className="py-12 text-center">
            <Building2 className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
            <h3 className="font-semibold mb-2">No banks connected</h3>
            <p className="text-muted-foreground mb-4">
              Connect your bank to automatically sync your transactions
            </p>
            <AddBankDialog />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
