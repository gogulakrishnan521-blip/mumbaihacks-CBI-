# FinZen - AI Financial Guardian

## Overview
FinZen is a comprehensive AI-powered financial dashboard application that helps users track their budget, set financial goals, manage transactions, and get personalized financial advice through an AI chat assistant.

## Project Architecture

### Frontend (React + TypeScript + Vite)
- **Location**: `client/src/`
- **Framework**: React with functional components
- **Routing**: wouter for client-side routing
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state
- **Charts**: Recharts for data visualization (pie charts, line charts)

### Backend (Express + TypeScript)
- **Location**: `server/`
- **Framework**: Express.js
- **Storage**: In-memory storage (MemStorage class)
- **AI Integration**: OpenAI GPT-5 for chat functionality (with fallback responses when API key not provided)

### Shared Types
- **Location**: `shared/schema.ts`
- All data models and Zod schemas for validation

## Key Features

1. **Dashboard** (`/`)
   - Daily financial goal display
   - Summary cards (balance, income, expenses, savings rate)
   - Budget pie chart breakdown by category
   - Stock portfolio line chart performance

2. **Goals** (`/goals`)
   - Long-term and short-term goal tracking
   - Progress bars and completion percentages
   - Add new goals with custom amounts and deadlines

3. **Transactions** (`/transactions`)
   - Transaction history with search and filtering
   - Category badges with color coding
   - Income/expense totals

4. **AI Chat** (`/chat`)
   - ChatGPT/Gemini-style interface
   - Financial advice and guidance
   - Falls back to pre-built responses if no OpenAI key

5. **Import Data** (`/import`)
   - CSV file upload with drag-and-drop
   - Preview and category editing before import
   - Bulk transaction creation

6. **Bank Connection** (`/bank`)
   - Connect bank accounts (UI ready, mocked backend)
   - Secure form with account/routing numbers
   - Connection status tracking

## API Endpoints

- `GET /api/dashboard` - Dashboard data with charts
- `GET /api/transactions` - List all transactions
- `POST /api/transactions` - Create single transaction
- `POST /api/transactions/bulk` - Bulk import transactions
- `GET /api/goals` - List all goals
- `POST /api/goals` - Create new goal
- `PATCH /api/goals/:id` - Update goal
- `DELETE /api/goals/:id` - Delete goal
- `GET /api/chat/messages` - Get chat history
- `POST /api/chat` - Send message to AI
- `DELETE /api/chat/messages` - Clear chat history
- `GET /api/bank-connections` - List bank connections
- `POST /api/bank-connections` - Add bank connection
- `DELETE /api/bank-connections/:id` - Remove bank connection

## Environment Variables

- `OPENAI_API_KEY` (optional): OpenAI API key for AI chat functionality. Without this, the chat uses pre-built fallback responses.

## Design System

- **Theme**: Alpaca-inspired clean financial platform aesthetic
- **Colors**: Professional blue (#217 primary), with semantic colors for income (green) and expenses (red)
- **Typography**: Inter / IBM Plex Sans fonts
- **Dark Mode**: Full dark mode support with theme toggle

## Running the Project

The project runs via the "Start application" workflow which executes `npm run dev`.
This starts both the Express backend and Vite frontend on port 5000.
