import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getAIResponse } from "./openai";
import {
  insertTransactionSchema,
  insertGoalSchema,
  insertBankConnectionSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/dashboard", async (req, res) => {
    try {
      const data = await storage.getDashboardData();
      res.json(data);
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ error: "Failed to fetch dashboard data" });
    }
  });

  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Transactions error:", error);
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const transaction = insertTransactionSchema.parse(req.body);
      const created = await storage.createTransaction(transaction);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid transaction data", details: error.errors });
      } else {
        console.error("Create transaction error:", error);
        res.status(500).json({ error: "Failed to create transaction" });
      }
    }
  });

  app.post("/api/transactions/bulk", async (req, res) => {
    try {
      const schema = z.object({
        transactions: z.array(insertTransactionSchema),
      });
      const { transactions } = schema.parse(req.body);
      const created = await storage.createTransactionsBulk(transactions);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid transaction data", details: error.errors });
      } else {
        console.error("Bulk create transactions error:", error);
        res.status(500).json({ error: "Failed to import transactions" });
      }
    }
  });

  app.get("/api/goals", async (req, res) => {
    try {
      const goals = await storage.getGoals();
      res.json(goals);
    } catch (error) {
      console.error("Goals error:", error);
      res.status(500).json({ error: "Failed to fetch goals" });
    }
  });

  app.post("/api/goals", async (req, res) => {
    try {
      const goal = insertGoalSchema.parse(req.body);
      const created = await storage.createGoal(goal);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid goal data", details: error.errors });
      } else {
        console.error("Create goal error:", error);
        res.status(500).json({ error: "Failed to create goal" });
      }
    }
  });

  app.patch("/api/goals/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = insertGoalSchema.partial().parse(req.body);
      const updated = await storage.updateGoal(id, updates);
      if (!updated) {
        res.status(404).json({ error: "Goal not found" });
      } else {
        res.json(updated);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid goal data", details: error.errors });
      } else {
        console.error("Update goal error:", error);
        res.status(500).json({ error: "Failed to update goal" });
      }
    }
  });

  app.delete("/api/goals/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteGoal(id);
      if (!deleted) {
        res.status(404).json({ error: "Goal not found" });
      } else {
        res.status(204).send();
      }
    } catch (error) {
      console.error("Delete goal error:", error);
      res.status(500).json({ error: "Failed to delete goal" });
    }
  });

  app.get("/api/chat/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages();
      res.json(messages);
    } catch (error) {
      console.error("Chat messages error:", error);
      res.status(500).json({ error: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const schema = z.object({ message: z.string().min(1) });
      const { message } = schema.parse(req.body);

      await storage.createChatMessage({
        role: "user",
        content: message,
      });

      const aiResponse = await getAIResponse(message);

      await storage.createChatMessage({
        role: "assistant",
        content: aiResponse,
      });

      res.json({ success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid message", details: error.errors });
      } else {
        console.error("Chat error:", error);
        res.status(500).json({ error: "Failed to process chat message" });
      }
    }
  });

  app.delete("/api/chat/messages", async (req, res) => {
    try {
      await storage.clearChatMessages();
      res.status(204).send();
    } catch (error) {
      console.error("Clear chat error:", error);
      res.status(500).json({ error: "Failed to clear chat messages" });
    }
  });

  app.get("/api/bank-connections", async (req, res) => {
    try {
      const connections = await storage.getBankConnections();
      res.json(connections);
    } catch (error) {
      console.error("Bank connections error:", error);
      res.status(500).json({ error: "Failed to fetch bank connections" });
    }
  });

  app.post("/api/bank-connections", async (req, res) => {
    try {
      const connection = insertBankConnectionSchema.parse(req.body);
      const created = await storage.createBankConnection(connection);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid bank connection data", details: error.errors });
      } else {
        console.error("Create bank connection error:", error);
        res.status(500).json({ error: "Failed to create bank connection" });
      }
    }
  });

  app.delete("/api/bank-connections/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteBankConnection(id);
      if (!deleted) {
        res.status(404).json({ error: "Bank connection not found" });
      } else {
        res.status(204).send();
      }
    } catch (error) {
      console.error("Delete bank connection error:", error);
      res.status(500).json({ error: "Failed to delete bank connection" });
    }
  });

  return httpServer;
}
