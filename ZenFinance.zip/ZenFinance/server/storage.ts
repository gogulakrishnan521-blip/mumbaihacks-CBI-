import { randomUUID } from "crypto";
import type {
  Transaction,
  InsertTransaction,
  Goal,
  InsertGoal,
  ChatMessage,
  InsertChatMessage,
  BankConnection,
  InsertBankConnection,
  DashboardData,
  BudgetCategory,
  StockData,
} from "@shared/schema";

export interface IStorage {
  getDashboardData(): Promise<DashboardData>;
  getTransactions(): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  createTransactionsBulk(transactions: InsertTransaction[]): Promise<Transaction[]>;
  getGoals(): Promise<Goal[]>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(id: string, goal: Partial<InsertGoal>): Promise<Goal | undefined>;
  deleteGoal(id: string): Promise<boolean>;
  getChatMessages(): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearChatMessages(): Promise<void>;
  getBankConnections(): Promise<BankConnection[]>;
  createBankConnection(connection: InsertBankConnection): Promise<BankConnection>;
  deleteBankConnection(id: string): Promise<boolean>;
}

function generateStockData(): StockData[] {
  const data: StockData[] = [];
  let value = 45000;
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  
  for (let i = 0; i < 12; i++) {
    value = value + (Math.random() - 0.4) * 3000;
    value = Math.max(30000, Math.min(80000, value));
    data.push({
      date: months[i],
      value: Math.round(value),
    });
  }
  return data;
}

function generateBudgetPie(): BudgetCategory[] {
  return [
    { name: "Housing", amount: 1800, color: "hsl(var(--chart-1))" },
    { name: "Food", amount: 650, color: "hsl(var(--chart-2))" },
    { name: "Transportation", amount: 450, color: "hsl(var(--chart-3))" },
    { name: "Utilities", amount: 280, color: "hsl(var(--chart-4))" },
    { name: "Entertainment", amount: 350, color: "hsl(var(--chart-5))" },
    { name: "Other", amount: 420, color: "hsl(220 14% 50%)" },
  ];
}

export class MemStorage implements IStorage {
  private transactions: Map<string, Transaction>;
  private goals: Map<string, Goal>;
  private chatMessages: Map<string, ChatMessage>;
  private bankConnections: Map<string, BankConnection>;
  private stockData: StockData[];
  private budgetPie: BudgetCategory[];

  constructor() {
    this.transactions = new Map();
    this.goals = new Map();
    this.chatMessages = new Map();
    this.bankConnections = new Map();
    this.stockData = generateStockData();
    this.budgetPie = generateBudgetPie();
    
    this.seedData();
  }

  private seedData() {
    const sampleTransactions: InsertTransaction[] = [
      { date: "2024-01-15", description: "Grocery Store - Weekly Shopping", category: "food", amount: 127.50, type: "expense" },
      { date: "2024-01-14", description: "Monthly Salary", category: "income", amount: 5500, type: "income" },
      { date: "2024-01-13", description: "Gas Station", category: "transportation", amount: 45.00, type: "expense" },
      { date: "2024-01-12", description: "Electric Bill", category: "utilities", amount: 95.00, type: "expense" },
      { date: "2024-01-11", description: "Netflix Subscription", category: "entertainment", amount: 15.99, type: "expense" },
      { date: "2024-01-10", description: "Amazon Purchase", category: "shopping", amount: 89.99, type: "expense" },
      { date: "2024-01-09", description: "Pharmacy", category: "healthcare", amount: 32.50, type: "expense" },
      { date: "2024-01-08", description: "Rent Payment", category: "housing", amount: 1800, type: "expense" },
      { date: "2024-01-07", description: "Dividend Income", category: "investment", amount: 125.00, type: "income" },
      { date: "2024-01-06", description: "Restaurant Dinner", category: "food", amount: 65.00, type: "expense" },
    ];

    sampleTransactions.forEach((t) => {
      const id = randomUUID();
      this.transactions.set(id, { id, ...t });
    });

    const sampleGoals: InsertGoal[] = [
      { name: "Retirement Fund", targetAmount: 500000, currentAmount: 125000, deadline: "2045-12-31", type: "long-term", icon: "retirement" },
      { name: "House Down Payment", targetAmount: 80000, currentAmount: 35000, deadline: "2026-06-30", type: "long-term", icon: "home" },
      { name: "College Fund", targetAmount: 100000, currentAmount: 28000, deadline: "2035-08-01", type: "long-term", icon: "education" },
      { name: "Emergency Fund", targetAmount: 15000, currentAmount: 12500, deadline: "2024-12-31", type: "short-term", icon: "emergency" },
      { name: "Vacation to Japan", targetAmount: 5000, currentAmount: 2800, deadline: "2024-09-01", type: "short-term", icon: "vacation" },
      { name: "New Car Fund", targetAmount: 25000, currentAmount: 8000, deadline: "2025-06-30", type: "short-term", icon: "car" },
    ];

    sampleGoals.forEach((g) => {
      const id = randomUUID();
      this.goals.set(id, { id, ...g });
    });
  }

  async getDashboardData(): Promise<DashboardData> {
    const transactions = Array.from(this.transactions.values());
    const totalIncome = transactions
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);
    const totalExpenses = transactions
      .filter((t) => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      dailyGoal: "Review your monthly subscriptions and identify any services you no longer use. Canceling just one $15/month subscription saves you $180/year!",
      totalBalance: 47250.00,
      monthlyIncome: totalIncome || 5625,
      monthlyExpenses: totalExpenses || 3950,
      savingsRate: 29.8,
      budgetPie: this.budgetPie,
      stockData: this.stockData,
    };
  }

  async getTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const newTransaction: Transaction = { id, ...transaction };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  async createTransactionsBulk(transactions: InsertTransaction[]): Promise<Transaction[]> {
    const created: Transaction[] = [];
    for (const t of transactions) {
      const id = randomUUID();
      const newTransaction: Transaction = { id, ...t };
      this.transactions.set(id, newTransaction);
      created.push(newTransaction);
    }
    return created;
  }

  async getGoals(): Promise<Goal[]> {
    return Array.from(this.goals.values());
  }

  async createGoal(goal: InsertGoal): Promise<Goal> {
    const id = randomUUID();
    const newGoal: Goal = { id, ...goal };
    this.goals.set(id, newGoal);
    return newGoal;
  }

  async updateGoal(id: string, goal: Partial<InsertGoal>): Promise<Goal | undefined> {
    const existing = this.goals.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...goal };
    this.goals.set(id, updated);
    return updated;
  }

  async deleteGoal(id: string): Promise<boolean> {
    return this.goals.delete(id);
  }

  async getChatMessages(): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const timestamp = new Date().toISOString();
    const newMessage: ChatMessage = {
      id,
      role: message.role,
      content: message.content,
      timestamp,
    };
    this.chatMessages.set(id, newMessage);
    return newMessage;
  }

  async clearChatMessages(): Promise<void> {
    this.chatMessages.clear();
  }

  async getBankConnections(): Promise<BankConnection[]> {
    return Array.from(this.bankConnections.values());
  }

  async createBankConnection(connection: InsertBankConnection): Promise<BankConnection> {
    const id = randomUUID();
    const newConnection: BankConnection = {
      id,
      ...connection,
      status: "pending",
    };
    this.bankConnections.set(id, newConnection);

    setTimeout(() => {
      const conn = this.bankConnections.get(id);
      if (conn) {
        conn.status = Math.random() > 0.2 ? "connected" : "failed";
        this.bankConnections.set(id, conn);
      }
    }, 3000);

    return newConnection;
  }

  async deleteBankConnection(id: string): Promise<boolean> {
    return this.bankConnections.delete(id);
  }
}

export const storage = new MemStorage();
