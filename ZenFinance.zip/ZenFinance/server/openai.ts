import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user

let openai: OpenAI | null = null;

if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

const SYSTEM_PROMPT = `You are FinZen AI, a friendly and knowledgeable financial advisor assistant. Your role is to help users with:

1. **Budgeting**: Help users create, understand, and optimize their budgets
2. **Savings**: Provide strategies for saving money and building emergency funds
3. **Investing**: Explain investment concepts, asset allocation, and retirement planning
4. **Debt Management**: Help users understand and create plans to pay off debt
5. **Financial Goals**: Assist with setting and tracking financial goals
6. **General Financial Literacy**: Explain financial concepts in simple terms

Guidelines:
- Be encouraging and supportive, never judgmental about financial situations
- Provide actionable, practical advice
- Explain complex concepts in simple, easy-to-understand language
- When discussing investments, remind users that you provide educational information, not personalized investment advice
- Encourage users to consult licensed financial advisors for major financial decisions
- Use specific numbers and examples when helpful
- Keep responses concise but thorough
- Format responses with clear structure using bullet points or numbered lists when appropriate

Remember: You're a helpful guide on the user's journey to financial wellness!`;

const FALLBACK_RESPONSES: Record<string, string> = {
  budget: `Here are some budgeting tips to help you manage your money better:

**The 50/30/20 Rule:**
- 50% for needs (rent, utilities, groceries)
- 30% for wants (entertainment, dining out)
- 20% for savings and debt repayment

**Quick Tips:**
1. Track every expense for a month to understand your spending patterns
2. Set up automatic transfers to your savings account on payday
3. Review and cancel unused subscriptions
4. Use cash for discretionary spending to better control impulses

Would you like more specific guidance on any of these areas?`,

  savings: `Here are some proven strategies to boost your savings:

**Start with These Steps:**
1. Set a specific savings goal (emergency fund, vacation, down payment)
2. Open a high-yield savings account
3. Automate your savings - "pay yourself first"
4. Start with even $25-50 per paycheck

**The Emergency Fund:**
Aim for 3-6 months of expenses. Start with $1,000 as your first milestone.

**Reduce Expenses:**
- Review subscriptions monthly
- Cook at home more often
- Shop with a list to avoid impulse buys
- Compare prices before major purchases

Small consistent savings grow into big results over time!`,

  invest: `Here's an overview of investing basics:

**Getting Started:**
1. First, build your emergency fund (3-6 months expenses)
2. Take advantage of employer 401(k) match - it's free money!
3. Consider low-cost index funds for diversification
4. Start early - time in the market beats timing the market

**Key Concepts:**
- **Diversification**: Don't put all eggs in one basket
- **Dollar-cost averaging**: Invest regularly regardless of market conditions
- **Compound interest**: Your earnings generate more earnings over time

**Risk Tolerance**: Your investment mix should match your timeline and comfort with volatility.

*Note: This is educational information, not personalized investment advice. Consider consulting a licensed financial advisor.*`,

  default: `I'm your FinZen AI financial assistant! I can help you with:

- **Budgeting**: Creating and optimizing your budget
- **Savings**: Strategies to save more money
- **Investing**: Understanding investment basics
- **Debt**: Managing and paying off debt
- **Goals**: Setting and tracking financial goals

What financial topic would you like to explore today?

*Note: For the best experience with personalized AI responses, please add your OpenAI API key in the project settings.*`,
};

function getFallbackResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes("budget") || lowerMessage.includes("spend")) {
    return FALLBACK_RESPONSES.budget;
  }
  if (lowerMessage.includes("save") || lowerMessage.includes("saving") || lowerMessage.includes("emergency")) {
    return FALLBACK_RESPONSES.savings;
  }
  if (lowerMessage.includes("invest") || lowerMessage.includes("stock") || lowerMessage.includes("401k") || lowerMessage.includes("retire")) {
    return FALLBACK_RESPONSES.invest;
  }
  
  return FALLBACK_RESPONSES.default;
}

export async function getAIResponse(userMessage: string): Promise<string> {
  if (!openai) {
    return getFallbackResponse(userMessage);
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userMessage },
      ],
      max_completion_tokens: 1024,
    });

    return response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    return getFallbackResponse(userMessage);
  }
}
