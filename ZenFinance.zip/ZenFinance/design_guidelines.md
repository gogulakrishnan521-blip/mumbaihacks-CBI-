# FinZen AI Financial Guardian - Design Guidelines

## Design Approach

**Reference-Based Approach**: Drawing from **Alpaca** (trading platform) for main dashboard and data visualization sections, with **ChatGPT/Gemini** patterns for the AI chat interface.

**Core Design Principle**: Professional financial platform aesthetic that balances data density with clarity, emphasizing trust and precision.

---

## Typography

- **Primary Font**: Inter or IBM Plex Sans (clean, professional fintech standard)
- **Headings**: Semi-bold (600) for section titles, 24-32px
- **Body Text**: Regular (400), 14-16px for readable data
- **Data/Numbers**: Tabular figures, medium weight (500), 16-20px for prominence
- **Chart Labels**: 12-14px, medium weight

---

## Layout System

**Spacing Units**: Tailwind units of **4, 6, 8, 12, 16** for consistent rhythm (p-4, m-6, gap-8, py-12, px-16)

**Grid Structure**:
- Main dashboard: Sidebar navigation (240px fixed) + fluid content area
- Content: 12-column responsive grid with 6-unit gaps
- Cards: 2-3 column layout on desktop, single column on mobile

---

## Component Library

### Navigation & Structure
- **Sidebar Navigation**: Fixed left sidebar (240px) with icon + label navigation items, collapsible on mobile
- **Top Bar**: Slim header (64px) with app title, user profile, and notifications icon
- **Page Container**: max-w-7xl with horizontal padding of 16 units

### Dashboard Components

**Summary Cards** (Alpaca-inspired):
- Clean white cards with subtle border (1px gray-200)
- Padding: p-6
- Grid layout: 4 cards spanning full width (grid-cols-1 md:grid-cols-2 lg:grid-cols-4)
- Each card shows: metric label (text-sm gray-600), value (text-2xl font-semibold), trend indicator (small colored pill)

**Chart Cards**:
- Larger white cards (p-8) with clear section headers
- Budget Pie Chart: Left-aligned in 2-column grid
- Stock Line Chart: Right-aligned in same grid
- Chart height: 320px with responsive scaling
- Legend positioned below charts with clean typography

**Transaction Table**:
- Striped rows for readability (alternate subtle gray background)
- Compact row height with 12-unit padding
- Columns: Date, Description, Category (colored badge), Amount (right-aligned, green/red)
- Filter chips above table for category selection

### Goals Dashboard

**Two-Section Layout**:
- Long-term goals section (top): 3-column grid of goal cards
- Short-term goals section (bottom): 3-column grid of goal cards

**Goal Cards**:
- White card with 8-unit padding
- Goal icon/emoji at top
- Goal name (text-lg font-semibold)
- Target amount and current progress
- Progress bar (8px height, rounded, colored fill based on completion)
- Timeline/deadline text (text-sm gray-600)
- Completion percentage (text-2xl) displayed prominently

### AI Chat Interface (ChatGPT/Gemini-style)

**Chat Layout**:
- Full-height panel (right side overlay or dedicated page)
- Background: light gray (gray-50)
- Messages container: centered max-w-3xl with scrollable area

**Message Bubbles**:
- User messages: Right-aligned, blue/purple background, white text, rounded-2xl, max-w-md
- AI messages: Left-aligned, white background, dark text, rounded-2xl, max-w-2xl
- Avatar icons: 32px circles next to each message
- Spacing between messages: 6 units
- Message padding: px-5 py-3

**Input Area**:
- Fixed bottom position with backdrop blur
- Rounded input field (rounded-xl) with shadow
- Send button integrated into input (right side, icon-only)
- Input height: 56px with comfortable padding

### Transaction Import

**CSV Upload Card**:
- Dashed border drag-and-drop zone (min-height 240px)
- Upload icon centered with "Drop CSV here or click to browse" text
- File preview table appears below after upload (compact table with 5-row preview)

**Bank Connection Card**:
- Form layout with labeled input fields
- Fields: Bank name (dropdown), Account number, Routing number
- "Connect Bank" primary button at bottom
- Security badge/text for trust indicators

---

## Visual Hierarchy

- **Primary Actions**: Solid buttons with 12-unit height, semi-bold text
- **Secondary Actions**: Outlined buttons or text buttons
- **Data Emphasis**: Use color sparingly - green for positive, red for negative, blue for neutral highlights
- **Section Headers**: Border-bottom divider (1px) with 4-unit padding below

---

## Animations

**Minimal, Purposeful Animations**:
- Chat messages: Gentle fade-in (200ms) on appearance
- Card hover: Subtle lift shadow (transition-shadow 150ms)
- Charts: No animation on load for data integrity
- Page transitions: Simple fade (150ms)

---

## Images

**No hero images required** - This is a data-focused dashboard application. All visual interest comes from charts, data visualization, and clean UI structure.

**Icons**: Use Heroicons (outline style) for navigation and UI elements - maintain consistency throughout.

---

## Accessibility

- Maintain WCAG AA contrast ratios for all text
- Interactive elements minimum 44px touch targets
- Proper ARIA labels for chart elements and data tables
- Keyboard navigation support for all interactive components
- Focus indicators visible on all form inputs and buttons