import json
import re
import sys
import os
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold

sys.path.append(os.getcwd())
from app.core.database import SessionLocal
from app.db.models import User, Budget, Transaction
from app.services.cfp_math import CFPLogicEngine
from app.services.calculators import FinancialCalculator
from app.services.rag_engine import FinZenMemory
from app.core.domain_rules import *

# --- CONFIGURATION ---
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "PASTE_YOUR_KEY_HERE")
genai.configure(api_key=GEMINI_API_KEY)
MODEL_NAME = "gemini-2.0-flash"

# --- SAFETY SETTINGS (Disable Censorship for Finance) ---
SAFETY = {
    HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
}

# --- ROUTER PROMPT ---
ROUTER_PROMPT = """
You are the Intent Classifier for FinZen.
Map the user input to EXACTLY ONE category:

1. **TRADE_EXECUTION**: Explicit command to buy/sell a specific asset (e.g. "Buy Apple", "Invest $100").
   - NOTE: "Spending on snacks" is FINANCIAL_ADVISORY, NOT trade execution.
2. **STOCK_RESEARCH**: Asking for stock picks, comparisons, analysis ("What is best?", "Compare X and Y").
3. **PROPERTY_RESEARCH**: Real estate queries.
4. **INSURANCE_RESEARCH**: Insurance queries.
5. **TAX_PLANNING**: Tax calculations.
6. **FIN_CALC**: Math questions (SIP, EMI).
7. **FINANCIAL_ADVISORY**: "How do I recover?", "What did I do wrong?", "Budget help", "Emergency".
8. **GENERAL_CHAT**: Greetings, non-finance.

OUTPUT JSON: { "intent": "CATEGORY", "entities": ["list", "of", "names"] }
"""

class FinZenBrain:
    def __init__(self, user_id=1):
        self.db = SessionLocal()
        self.user = self.db.query(User).filter(User.id == user_id).first()
        self.math_engine = CFPLogicEngine(self.user, self.user.debts)
        self.memory = FinZenMemory()
        self.model = genai.GenerativeModel(MODEL_NAME)

    # --- HELPERS ---
    def clean_json_text(self, text):
        """Fixes common JSON formatting errors from LLMs"""
        text = text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
            text = text.rsplit("\n", 1)[0]
        return text

    def extract_amount_heuristic(self, query):
        """Finds numbers in text (e.g., '5000' from 'Invest 5000')"""
        matches = re.findall(r'[\d,]+', query)
        if matches:
            try: return float(matches[0].replace(",", ""))
            except: return 0.0
        return 0.0

    def calculate_financials(self, tool, inputs):
        calc = FinancialCalculator()
        try:
            if tool == "sip_calculator": return calc.sip_future_value(inputs.get('amount',0), inputs.get('rate',12), inputs.get('years',10))
            if tool == "loan_emi": return calc.loan_emi(inputs.get('amount',0), inputs.get('rate',9), inputs.get('years',20))
            return 0
        except: return 0

    # --- CORE FUNCTIONS ---
    def detect_intent(self, query):
        try:
            res = self.model.generate_content(
                f"{ROUTER_PROMPT}\nQUERY: '{query}'\nOUTPUT JSON ONLY.",
                safety_settings=SAFETY
            )
            return json.loads(self.clean_json_text(res.text))
        except: return {"intent": "GENERAL_CHAT", "entities": []}

    def consult(self, query, research_context=None, context_type="general"):
        # 1. Fetch Budget Context (Crucial for "What did I do wrong?")
        budgets = self.db.query(Budget).filter(Budget.user_id == self.user.id).all()
        budget_str = "\n".join([f"- {b.category}: Spent ₹{b.spent_so_far} / Limit ₹{b.limit_amount}" for b in budgets])

        # 2. Select System Prompt
        if context_type == "property":
            prompt = PROPERTY_SYSTEM_PROMPT
            user_context = f"DATA: Income ₹{self.user.monthly_income}, Cash ₹{self.user.emergency_fund_cash}. LISTINGS: {json.dumps(research_context)}"
        elif context_type == "insurance":
            prompt = INSURANCE_SYSTEM_PROMPT
            user_context = f"DATA: Age {self.user.age}, Income ₹{self.user.monthly_income * 12}. POLICIES: {json.dumps(research_context)}"
        elif context_type == "stock":
            prompt = STOCK_SYSTEM_PROMPT
            user_context = f"RISK: {self.user.risk_tolerance}. MARKET: {json.dumps(research_context)}"
        elif context_type == "tax":
            prompt = INDIAN_TAX_SYSTEM_PROMPT
            user_context = f"TAX DATA: Income ₹{self.user.monthly_income * 12}"
        else:
            # ADVISORY / GENERAL
            math_res = self.math_engine.run_analysis(0)
            past_mems = self.memory.recall(query)
            
            prompt = """
            You are FinZen, a Financial Mentor.
            RULES:
            1. Use the BUDGET STATUS below to answer "What did I do wrong?".
            2. Be helpful and detailed (Markdown).
            3. If user wants to TRADE (buy/sell assets), extract symbol/amount. Else symbol=null.
            
            OUTPUT SCHEMA: { "verdict": "INFO"|"APPROVE"|"WARNING", "response_text": "...", "extracted_symbol": null, "extracted_amount": 0 }
            """
            
            user_context = f"""
            USER CONTEXT:
            - Income: ₹{self.user.monthly_income}
            - Risk Score: {math_res['risk_score']}
            - Emergency Fund: {math_res['emergency_coverage']} months
            
            🛑 BUDGET STATUS:
            {budget_str}
            
            MEMORIES: {past_mems}
            """

        # 3. Call Gemini
        try:
            full_text = f"{prompt}\n{user_context}\nUSER QUERY: '{query}'\nOUTPUT JSON ONLY."
            
            response = self.model.generate_content(full_text, safety_settings=SAFETY)
            data = json.loads(self.clean_json_text(response.text))
            
            # --- 🚨 CRITICAL LIST FIX ---
            if isinstance(data, list):
                if len(data) > 0:
                    # Pick the 'Best' result or the first one
                    winner = next((item for item in data if item.get('verdict') == 'APPROVE'), data[0])
                    data = winner
                else:
                    data = {"verdict": "INFO", "response_text": "No valid analysis generated."}

            # Post-Process Math
            if context_type == "planning":
                tool = data.get('tool_used')
                if tool and tool != "none":
                    res = self.calculate_financials(tool, data.get('inputs_identified', {}))
                    data['response_text'] = f"Based on calculations, the result is ₹{res:,.2f}. {data.get('reasoning')}"

            # Memorize
            self.memory.memorize(f"Q: {query} | A: {data.get('response_text')[:50]}")
            return data
        
        except Exception as e:
            return {"verdict": "INFO", "response_text": f"Error: {str(e)}", "risk_score": 0}