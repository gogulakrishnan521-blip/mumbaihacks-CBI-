from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# ☁️ YOUR NEON CLOUD DATABASE URL
# (I pasted the one you just provided below)
SQLALCHEMY_DATABASE_URL = "postgresql://neondb_owner:npg_UMzKJ2xSv4CR@ep-lively-king-a18bf7pr-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"

# Create the Engine
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# Create Session Factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Declarative Base
Base = declarative_base()