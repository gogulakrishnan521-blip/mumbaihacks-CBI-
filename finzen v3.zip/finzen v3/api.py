import sys
import os
import uvicorn
import json
import yfinance as yf
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List, Union
from datetime import datetime

# Ensure Python sees your app modules
sys.path.append(os.getcwd())

from app.core.database import SessionLocal
from app.db.models import User, Budget, Asset, Goal, Commitment
from app.services.brain import FinZenBrain
from app.services.agent import InvestmentAgent
from app.services.researcher import MarketResearcher

# --- INIT APP ---
app = FastAPI(
    title="FinZen AI Backend",
    description="Agentic Financial Guardian API",
    version="V7.0"
)

# --- CORS (Allow Frontend Access) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow all for Hackathon demo
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- INSTANTIATE SERVICES ---
# In production, use dependency injection (Depends)
brain = FinZenBrain(user_id=1)
agent = InvestmentAgent(user_id=1)
researcher = MarketResearcher()

# --- DATA MODELS ---
class ChatRequest(BaseModel):
    message: str
    user_id: Union[int, str] = 1 # Allow string IDs from frontend

class ContextRequest(BaseModel):
    user_id: int = 1
    context_text: str

# (Removed strict ChatResponse model usage on endpoint to allow dynamic UI Cards)

# --- HELPER: GRAPH DATA ---
def get_stock_history_data(symbol: str):
    """Fetches 1-month historical data for charts"""
    try:
        # Fix Ticker for India
        if not symbol.endswith(".NS") and not symbol.isupper():
            symbol = f"{symbol.upper()}.NS"
        
        stock = yf.Ticker(symbol)
        hist = stock.history(period="1mo")
        
        data_points = []
        for date, row in hist.iterrows():
            data_points.append({
                "date": date.strftime("%d %b"),
                "price": round(row['Close'], 1),
                "value": round(row['Close'], 1) # Added 'value' key for Recharts
            })
        return data_points
    except:
        return []

# ============================================================
#  ENDPOINTS
# ============================================================

@app.get("/")
def health_check():
    return {"status": "online", "system": "FinZen V7 Agent"}

# --- 1. DASHBOARD DATA ENDPOINT ---
@app.get("/dashboard/{user_id}")
def get_dashboard(user_id: int):
    """Aggregates all data for the Frontend Dashboard."""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            # Fallback for demo if user DB is empty
            return {
                "user_name": "Siva",
                "net_worth": "₹12,50,000",
                "monthly_income": 85000,
                "daily_goal": "✅ Goal: Invest ₹500 in Nifty today.",
                "budget_pie": [
                    {"name": "Food", "value": 5000},
                    {"name": "Travel", "value": 3000},
                    {"name": "Rent", "value": 15000}
                ],
                "stock_graphs": []
            }

        # A. BUDGET PIE CHART
        budgets = db.query(Budget).filter(Budget.user_id == user_id).all()
        pie_data = []
        overspent_cats = []
        
        for b in budgets:
            if b.limit_amount > 0:
                pie_data.append({
                    "name": b.category,
                    "value": b.spent_so_far
                })
                if b.spent_so_far >= b.limit_amount:
                    overspent_cats.append(b.category)

        # B. STOCK GRAPHS (Top 2 Assets)
        assets = db.query(Asset).filter(Asset.user_id == user_id, Asset.asset_type.in_(["Stock", "Mutual Fund"])).limit(2).all()
        graphs = []
        
        for asset in assets:
            history = get_stock_history_data(asset.name)
            if history:
                graphs.append({
                    "symbol": asset.name,
                    "current_value": asset.current_value,
                    "data": history
                })

        # C. DAILY GOAL GENERATION
        if overspent_cats:
            daily_goal = f"⛔ STOP Spending on: {', '.join(overspent_cats[:2])}"
        else:
            daily_goal = "✅ Goal: Invest ₹500 in Nifty today."

        return {
            "user_name": user.username,
            "net_worth": f"₹{(user.monthly_income * 12) + user.emergency_fund_cash:,.0f}", # Simple proxy
            "monthly_income": user.monthly_income,
            "risk_score": 20, 
            "daily_goal": daily_goal,
            "budget_pie": pie_data,
            "stock_graphs": graphs
        }
    finally:
        db.close()

# --- 2. CONTEXT UPDATE ENDPOINT ---
@app.post("/update-context")
async def update_personal_context(request: ContextRequest):
    """Saves user life updates (e.g., 'Getting married')."""
    brain.memory.memorize(f"USER LIFE UPDATE: {request.context_text}")
    return {"status": "success", "message": "Context memorized."}

# --- 3. MAIN CHAT ENDPOINT ---
@app.post("/chat")
async def chat_endpoint(request: ChatRequest):
    user_input = request.message.strip()
    
    if not user_input:
        raise HTTPException(status_code=400, detail="Empty message")

    # A. HANDLE ONBOARDING (API KEYS)
    if user_input.startswith("PK") and len(user_input) > 10:
        res = agent.link_account(user_input, "dummy_secret_for_demo") 
        return {
            "role": "assistant",
            "type": "text",
            "content": f"🔑 {res}"
        }

    # B. DETECT INTENT (Semantic Router)
    intent_data = brain.detect_intent(user_input)
    intent = intent_data.get("intent", "GENERAL_CHAT")
    entities = intent_data.get("entities", [])

    context_type = "general"
    results = None
    action_status = "NONE"

    # C. ROUTE TO EXPERTS
    try:
        if intent == "STOCK_RESEARCH":
            context_type = "stock"
            results = researcher.compare_stocks(entities) if entities else researcher.find_best_stock()
            action_status = "RESEARCHED"

        elif intent == "PROPERTY_RESEARCH":
            context_type = "property"
            loc = "Mumbai"
            if "in" in user_input: loc = user_input.split("in")[-1].strip()
            results = researcher.find_properties(loc) 
            action_status = "RESEARCHED"

        elif intent == "INSURANCE_RESEARCH":
            context_type = "insurance"
            ins_type = "Health" if "medical" in user_input.lower() else "Term Life"
            results = researcher.find_insurance(ins_type, brain.user.age, brain.user.monthly_income * 12)
            action_status = "RESEARCHED"

        elif intent == "TAX_PLANNING":
            context_type = "tax"
            action_status = "CALCULATED"

        elif intent == "FIN_CALC":
            context_type = "planning"
            action_status = "CALCULATED"

        elif intent == "TRADE_EXECUTION":
            context_type = "general"

        # D. CONSULT BRAIN
        decision = brain.consult(user_input, research_context=results, context_type=context_type)
        
        response_text = decision.get('response_text', '')
        verdict = decision.get('verdict', 'INFO')
        risk = decision.get('risk_score', 0)

        # E. EXECUTION LOGIC (Strict Gate)
        trade_details = None
        if intent == "TRADE_EXECUTION":
            sym = decision.get('extracted_symbol')
            amt = decision.get('extracted_amount')
            
            if sym and amt and amt > 0 and str(sym).lower() != "null":
                if verdict in ["APPROVE", "WARNING"]:
                    # EXECUTE TRADE
                    trade_res = agent.execute_buy(sym, amt)
                    response_text += f"\n\n🚀 **ACTION:** {trade_res}"
                    action_status = "TRADED"
                    trade_details = {"symbol": sym, "amount": amt}
                else:
                    response_text += f"\n\n🛑 **BLOCKED:** Trade rejected due to High Risk Score ({risk}/100)."
                    action_status = "BLOCKED"

        # =========================================================
        # F. FORMAT RESPONSE FOR REACT UI (STOCK CARDS / TICKETS)
        # =========================================================
        
        # Default: Text Response
        response_payload = {
            "role": "assistant",
            "type": "text",
            "content": response_text
        }

        # 1. UI Stock Card Logic
        if action_status == "RESEARCHED" and results:
            # Check if we have enough data for a card (Symbol + Price)
            # This depends on what 'results' structure your researcher returns
            # Assuming 'results' is a dict with 'symbol' and 'price'
            symbol_data = results if isinstance(results, dict) else {}
            
            # If researcher just returned text, try to extract symbol from entities
            target_symbol = symbol_data.get('symbol') or (entities[0] if entities else None)

            if target_symbol:
                history_data = get_stock_history_data(target_symbol)
                current_price = history_data[-1]['price'] if history_data else 0
                
                response_payload = {
                    "role": "assistant",
                    "type": "stock-card",
                    "data": {
                        "symbol": str(target_symbol).upper(),
                        "name": symbol_data.get('longName', 'Stock Asset'),
                        "price": current_price,
                        "change": 2.5, # Mock change if not available real-time
                        "history": history_data
                    }
                }
                # Prepend the text explanation
                response_payload["content"] = response_text

        # 2. UI Trade Ticket Logic
        elif action_status == "TRADED" and trade_details:
             response_payload = {
                "role": "assistant",
                "type": "trade-ticket",
                "data": {
                    "symbol": trade_details['symbol'],
                    "qty": trade_details['amount'],
                    "price": 100.0, # You can fetch real price here if needed
                    "status": "filled"
                }
             }

        return response_payload

    except Exception as e:
        print(f"Error: {e}")
        return {
            "role": "system",
            "type": "text",
            "content": f"I encountered a system error: {str(e)}"
        }

if __name__ == "__main__":
    print("🚀 FinZen API Starting on Port 8000...")
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)